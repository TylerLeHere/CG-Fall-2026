////////////////////////////////////////////////////////////////////////////////
// C++ include
#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include <fstream>
#include <algorithm>
#include <numeric>

// Utilities for the Assignment
#include "utils.h"

// Image writing library
#define STB_IMAGE_WRITE_IMPLEMENTATION // Do not include this line twice in your project!
#include "stb_image_write.h"

// Shortcut to avoid Eigen:: everywhere, DO NOT USE IN .h
using namespace Eigen;

////////////////////////////////////////////////////////////////////////////////
// Class to store tree
////////////////////////////////////////////////////////////////////////////////
class AABBTree
{
public:
    class Node
    {
    public:
        AlignedBox3d bbox;
        int parent;   // Index of the parent node (-1 for root)
        int left;     // Index of the left child (-1 for a leaf)
        int right;    // Index of the right child (-1 for a leaf)
        int triangle; // Index of the node triangle (-1 for internal nodes)
    };

    std::vector<Node> nodes;
    int root = -1;

    AABBTree() = default;                           // Default empty constructor
    AABBTree(const MatrixXd &V, const MatrixXi &F); // Build a BVH from an existing mesh

private:
    // builds the bvh recursively
    int build_recursive(const MatrixXd &V, const MatrixXi &F, const MatrixXd &centroids, int from, int to, int parent, std::vector<int> &triangles);
};

////////////////////////////////////////////////////////////////////////////////
// Scene setup, global variables
////////////////////////////////////////////////////////////////////////////////
const std::string data_dir = DATA_DIR;
const std::string filename("raytrace.png");
const std::string mesh_filename(data_dir + "bunny.off");

const bool use_bvh = true; // Setting this to be true to use AABB tree in EX2

const bool enable_sphere_and_parallelograms = true; // Bonus 1
const bool enable_shadows = true; // Bonus 2
const bool enable_reflections = true; // Bonus 3
const int max_bounce = 3;
std::vector<Vector3d> sphere_centers;
std::vector<double> sphere_raddi;
std::vector<Matrix3d> parallelograms;



//Camera settings
const double focal_length = 2;
const double field_of_view = 0.7854; //45 degrees
const bool is_perspective = true;
const Vector3d camera_position(0, 0, 2);

// Triangle Mesh
MatrixXd vertices; // n x 3 matrix (n points)
MatrixXi facets;   // m x 3 matrix (m triangles)
AABBTree bvh;

//Material for the object, same material for all objects
const Vector4d obj_ambient_color(0.0, 0.5, 0.0, 0);
const Vector4d obj_diffuse_color(0.5, 0.5, 0.5, 0);
const Vector4d obj_specular_color(0.2, 0.2, 0.2, 0);
const double obj_specular_exponent = 256.0;
const Vector4d obj_reflection_color(0.7, 0.7, 0.7, 0);

// Precomputed (or otherwise) gradient vectors at each grid node
const int grid_size = 20;
std::vector<std::vector<Vector2d>> grid;

//Lights
std::vector<Vector3d> light_positions;
std::vector<Vector4d> light_colors;
//Ambient light
const Vector4d ambient_light(0.2, 0.2, 0.2, 0);

//Fills the different arrays
void setup_scene()
{
    //Loads file
    std::ifstream in(mesh_filename);
    std::string token;
    in >> token;
    int nv, nf, ne;
    in >> nv >> nf >> ne;
    vertices.resize(nv, 3);
    facets.resize(nf, 3);
    for (int i = 0; i < nv; ++i)
    {
        in >> vertices(i, 0) >> vertices(i, 1) >> vertices(i, 2);
    }
    for (int i = 0; i < nf; ++i)
    {
        int s;
        in >> s >> facets(i, 0) >> facets(i, 1) >> facets(i, 2);
        assert(s == 3);
    }

    //setup tree
    bvh = AABBTree(vertices, facets);

    if(enable_sphere_and_parallelograms)
    {
        // Left Spheres
        sphere_centers.emplace_back(-0.8, -0.3, 0.1);
        sphere_raddi.emplace_back(0.2);
        
        // Right Spheres
        sphere_centers.emplace_back(0.8, -0.25, -0.3);
        sphere_raddi.push_back(0.25);

        Matrix3d floor_corners;
        floor_corners.col(0) = Vector3d(-10, -0.5, -10);
        floor_corners.col(1) = Vector3d(-10, -0.5, 10);
        floor_corners.col(2) = Vector3d(10, -0.5, -10);
        parallelograms.emplace_back(floor_corners);
    }

    //Lights
    light_positions.emplace_back(8, 8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(6, -8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(4, 8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(2, -8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(0, 8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(-2, -8, 0);
    light_colors.emplace_back(16, 16, 16, 0);

    light_positions.emplace_back(-4, 8, 0);
    light_colors.emplace_back(16, 16, 16, 0);
}

////////////////////////////////////////////////////////////////////////////////
// BVH Code
////////////////////////////////////////////////////////////////////////////////

AlignedBox3d bbox_from_triangle(const Vector3d &a, const Vector3d &b, const Vector3d &c)
{
    AlignedBox3d box;
    box.extend(a);
    box.extend(b);
    box.extend(c);
    return box;
}

AABBTree::AABBTree(const MatrixXd &V, const MatrixXi &F)
{
    // Compute the centroids of all the triangles in the input mesh
    MatrixXd centroids(F.rows(), V.cols());
    centroids.setZero();
    for (int i = 0; i < F.rows(); ++i)
    {
        for (int k = 0; k < F.cols(); ++k)
        {
            centroids.row(i) += V.row(F(i, k));
        }
        centroids.row(i) /= F.cols();
    }

    //Vector containing the list of tringle indices
    std::vector<int> triangles(F.rows());
    std::iota(triangles.begin(), triangles.end(), 0);

    root = build_recursive(V, F, centroids, 0, triangles.size(), -1, triangles);
}

int AABBTree::build_recursive(const MatrixXd &V, const MatrixXi &F, const MatrixXd &centroids, int from, int to, int parent, std::vector<int> &triangles)
{
    // Scene is empty, so is the aabb tree
    if (to - from == 0)
    {
        return -1;
    }

    // If there is only 1 triangle left, then we are at a leaf
    if (to - from == 1)
    {

        const int triangle = triangles[from];
        const Vector3d a = V.row(F(triangle, 0)).transpose();
        const Vector3d b = V.row(F(triangle, 1)).transpose();
        const Vector3d c = V.row(F(triangle, 2)).transpose();

        Node leaf;
        leaf.bbox = bbox_from_triangle(a, b, c);
        leaf.parent = parent;
        leaf.left = -1;
        leaf.right = -1;
        leaf.triangle = triangle;

        nodes.push_back(leaf);
        return static_cast<int>(nodes.size()) - 1;
    }

    // Find the box around this group's centroids.
    AlignedBox3d centroid_box;
    for (int i = from; i < to; ++i)
    {
        const Vector3d centroid = centroids.row(triangles[i]).transpose();
        centroid_box.extend(centroid);
    }

    // Diagonal of the box
    Vector3d extent = centroid_box.diagonal();

    // Sort triangle indices along the longest centroid axis.
    Eigen::Index longest_dim_axis;
    extent.maxCoeff(&longest_dim_axis);

    std::sort(triangles.begin() + from, triangles.begin() + to, [&](int f1, int f2) {
        return centroids(f1, longest_dim_axis) < centroids(f2, longest_dim_axis);
    });

    // Add the parent first so the children can store its index.
    Node node;
    node.parent = parent;
    node.left = -1;
    node.right = -1;
    node.triangle = -1;

    const int index = static_cast<int>(nodes.size());
    nodes.push_back(node);

    // Split into two halves and build the children 
    const int mid = from + (to - from + 1) / 2;
    const int left = build_recursive(V, F, centroids, from, mid, index, triangles);
    const int right = build_recursive(V, F, centroids, mid, to, index, triangles);

    // Recursion can reallocate nodes, so access the parent by index.
    nodes[index].left = left;
    nodes[index].right = right;
    nodes[index].bbox = nodes[left].bbox.merged(nodes[right].bbox);

    return index;
}

double ray_triangle_intersection(const Vector3d &ray_origin, const Vector3d &ray_direction, const Vector3d &a, const Vector3d &b, const Vector3d &c, Vector3d &p, Vector3d &N)
{
    bool is_invertible;
    Matrix3d inverse;
    const Vector3d edge_u = b - a;
    const Vector3d edge_v = c - a;

    Matrix3d system;
    system.col(0) = -ray_direction;
    system.col(1) = edge_u;
    system.col(2) = edge_v;

    system.computeInverseWithCheck(inverse, is_invertible);
    // If it can not be inverted, then the ray is parallel to the triangle plane, so there is no intersection
    if (!is_invertible)
    {
        return -1;
    }

    const Vector3d sol = inverse * (ray_origin - a);
    const double t = sol(0);
    const double u = sol(1);
    const double v = sol(2);

    // The intersection must be inside the triangle and along the ray, so t, u and v must be positive and u + v <= 1
    if (t < 0 || u < 0 || v < 0 || u + v > 1)
    {
        return -1;
    }

    p = ray_origin + t * ray_direction;

    // The normal of the triangle is the cross product of its edges
    N = edge_u.cross(edge_v).normalized();
    if(N.dot(ray_direction) > 0)
    {
        N = -N;
    }
    return t;
}

bool ray_box_intersection(const Vector3d &ray_origin, const Vector3d &ray_direction, const AlignedBox3d &box)
{
    if(box.isEmpty()){
        return false;
    }

    double t_enter = 0.0;
    double t_exit = std::numeric_limits<double>::infinity();

    for (int axis = 0; axis < 3; ++axis){
        const double origin = ray_origin(axis);
        const double direction = ray_direction(axis);
        const double box_min = box.min()(axis);
        const double box_max = box.max()(axis);

        if (direction == 0.0){
            if (origin < box_min || origin > box_max){
                return false;
            }
            continue;
        }

        // The ray crosses each plan on the axis here
        double t_near = (box_min - origin) / direction;
        double t_far = (box_max - origin) / direction;

        if (t_near > t_far){
            std::swap(t_near, t_far);
        }

        t_enter = std::max(t_enter, t_near);
        t_exit = std::min(t_exit, t_far);

        if (t_enter > t_exit){
            return false;
        }
    }

    return true;
}



double ray_sphere_intersection(const Vector3d &ray_origin, const Vector3d &ray_direction, int sphere_index, Vector3d &p, Vector3d &N)
{

    const Vector3d sphere_center = sphere_centers[sphere_index];
    const double sphere_radius = sphere_raddi[sphere_index];

    const Vector3d oc = ray_origin - sphere_center;
    const double a = ray_direction.dot(ray_direction);
    const double b = 2.0 * ray_direction.dot(oc);
    const double c = oc.dot(oc) - sphere_radius * sphere_radius;

    const double discriminant = b * b - 4 * a * c;
    if (discriminant < 0)
    {
        return -1; // No intersection
    }
    else
    {
        // Find the nearest intersection point
        const double sqrt_discriminant = std::sqrt(discriminant);
        const double t1 = (-b - sqrt_discriminant) / (2.0 * a);
        const double t2 = (-b + sqrt_discriminant) / (2.0 * a);

        double t = std::min(t1, t2);
        if (t < 0)
        {
            t = std::max(t1, t2); // If the nearest intersection is behind the ray origin, check the other intersection
            if (t < 0)
            {
                return -1; // Both intersections are behind the ray origin
            }
        }

        p = ray_origin + t * ray_direction;
        N = (p - sphere_center).normalized();
        return t;
    }
}

double ray_parallelogram_intersection(const Vector3d &ray_origin, const Vector3d &ray_direction, int parallelogram_index, Vector3d &p, Vector3d &N)
{
    const Vector3d pgram_origin = parallelograms[parallelogram_index].col(0);
    const Vector3d edge_u = parallelograms[parallelogram_index].col(1) - pgram_origin;
    const Vector3d edge_v = parallelograms[parallelogram_index].col(2) - pgram_origin;

    Matrix3d system;
    system.col(0) = -ray_direction;
    system.col(1) = edge_u;
    system.col(2) = edge_v;

    bool is_invertible;
    Matrix3d inverse;
    system.computeInverseWithCheck(inverse, is_invertible);
    if (!is_invertible){
        return -1; // Ray is parallel to the parallelogram plane
    }

    const Vector3d sol = inverse * (ray_origin - pgram_origin);
    const double t = sol(0);
    const double u = sol(1);
    const double v = sol(2);

    if (t < 0 || u < 0 || v < 0 || u > 1 || v > 1){
        return -1; // Intersection is outside the parallelogram
    }

    p = ray_origin + t * ray_direction;
    N = edge_u.cross(edge_v).normalized();
    if(N.dot(ray_direction) > 0){
        N = -N; // Ensure the normal is facing against the ray direction
    }
    return t;
}

bool find_nearest_object(const Vector3d &ray_origin, const Vector3d &ray_direction, Vector3d &p, Vector3d &N)
{
    Vector3d tmp_p, tmp_N;
    double nearest_t = std::numeric_limits<double>::max();
    bool hit = false;

    auto update_closest_hit = [&](double t) {
        if (t >= 0 && t < nearest_t)
        {
            nearest_t = t;
            p = tmp_p;
            N = tmp_N;
            hit = true;
        }
    };
    
    // Tests one by one all the triangles in the mesh, and keeps it if it is the cloest
    auto triangle_test = [&](int triangle){
        const Vector3d a = vertices.row(facets(triangle, 0));
        const Vector3d b = vertices.row(facets(triangle, 1));
        const Vector3d c = vertices.row(facets(triangle, 2));

        const double t = ray_triangle_intersection(ray_origin, ray_direction, a, b, c, tmp_p, tmp_N);
        update_closest_hit(t);
    };

    if (enable_sphere_and_parallelograms)
    {
        for (int i = 0; i < sphere_centers.size(); ++i)
        {
            const double t = ray_sphere_intersection(ray_origin, ray_direction, i, tmp_p, tmp_N);
            update_closest_hit(t);
        }

        for (int i = 0; i < parallelograms.size(); ++i)
        {
            const double t = ray_parallelogram_intersection(ray_origin, ray_direction, i, tmp_p, tmp_N);
            update_closest_hit(t);
        }
    }

    if (!use_bvh)
    {
        for (int i = 0; i < facets.rows(); ++i)
        {
            triangle_test(i);
        }
        return hit;
    }

    // Ex2: Traverse the bounding box tree

    std::vector<int> to_visit;
    if(bvh.root != -1){
        to_visit.push_back(bvh.root);
    }

    while(!to_visit.empty())
    {
        const int index = to_visit.back();
        to_visit.pop_back();

        const AABBTree::Node &node = bvh.nodes[index];

        if(!ray_box_intersection(ray_origin, ray_direction, node.bbox)){
            continue;
        }

        if (node.triangle != -1){
            triangle_test(node.triangle);
        } else {
            to_visit.push_back(node.left);
            to_visit.push_back(node.right);
        }
    }
    return hit;

}

bool is_light_visible(const Vector3d &ray_origin, const Vector3d &ray_direction, const Vector3d &light_position){
    Vector3d hit_point, hit_normal;
    if(!find_nearest_object(ray_origin, ray_direction, hit_point, hit_normal)){
        return true; // No intersection, light is visible
    }

    const double hit_distance = (hit_point - ray_origin).norm();
    const double light_distance = (light_position - ray_origin).norm();
    return hit_distance > light_distance; // Light is visible if the intersection is farther than the light
}



////////////////////////////////////////////////////////////////////////////////
// Raytracer code
////////////////////////////////////////////////////////////////////////////////

Vector4d shoot_ray(const Vector3d &ray_origin, const Vector3d &ray_direction, int bounces)
{
    //Intersection point and normal, these are output of find_nearest_object
    Vector3d p, N;

    const bool nearest_object = find_nearest_object(ray_origin, ray_direction, p, N);

    if (!nearest_object)
    {
        // Return a transparent color
        return Vector4d(0, 0, 0, 0);
    }

    // Ambient light contribution
    const Vector4d ambient_color = obj_ambient_color.array() * ambient_light.array();

    // Punctual lights contribution (direct lighting)
    Vector4d lights_color(0, 0, 0, 0);
    for (int i = 0; i < light_positions.size(); ++i)
    {
        const Vector3d &light_position = light_positions[i];
        const Vector4d &light_color = light_colors[i];

        Vector4d diff_color = obj_diffuse_color;

        // Diffuse contribution
        const Vector3d Li = (light_position - p).normalized();
        const Vector3d shadow_ray_origin = p + 1e-4 * Li; // Offset the origin to avoid self-intersection
        if(enable_shadows && !is_light_visible(shadow_ray_origin, Li, light_position)){
            continue; // Light is blocked, skip this light
        }
        const Vector4d diffuse = diff_color * std::max(Li.dot(N), 0.0);

        // Specular contribution
        const Vector3d Hi = (Li - ray_direction).normalized();
        const Vector4d specular = obj_specular_color * std::pow(std::max(N.dot(Hi), 0.0), obj_specular_exponent);
        // Vector3d specular(0, 0, 0);

        // Attenuate lights according to the squared distance to the lights
        const Vector3d D = light_position - p;
        lights_color += (diffuse + specular).cwiseProduct(light_color) / D.squaredNorm();
    }

    // Rendering equation
    Vector4d reflection_color(0, 0, 0, 0);
    if(enable_reflections && bounces > 0)
    {
        const Vector3d reflected_direction = ray_direction - 2 * ray_direction.dot(N) * N;
        const Vector3d reflected_origin = p + 1e-4 * reflected_direction; // Offset the origin to avoid self-intersection
        reflection_color = obj_reflection_color.cwiseProduct(shoot_ray(reflected_origin, reflected_direction, bounces - 1));
    }
    Vector4d C = ambient_color + lights_color + reflection_color;
    C(3) = 1; // Set alpha to 1 for opaque objects
    return C;
}


void raytrace_scene()
{
    std::cout << "Simple ray tracer." << std::endl;

    int w = 640;
    int h = 480;
    MatrixXd R = MatrixXd::Zero(w, h);
    MatrixXd G = MatrixXd::Zero(w, h);
    MatrixXd B = MatrixXd::Zero(w, h);
    MatrixXd A = MatrixXd::Zero(w, h); // Store the alpha mask

    // The camera always points in the direction -z
    // The sensor grid is at a distance 'focal_length' from the camera center,
    // and covers an viewing angle given by 'field_of_view'.
    double aspect_ratio = double(w) / double(h);
    //TODO
    double image_y = focal_length * std::tan(field_of_view / 2.0);
    double image_x = image_y * aspect_ratio;

    // The pixel grid through which we shoot rays is at a distance 'focal_length'
    const Vector3d image_origin(-image_x, image_y, camera_position[2] - focal_length);
    const Vector3d x_displacement(2.0 / w * image_x, 0, 0);
    const Vector3d y_displacement(0, -2.0 / h * image_y, 0);

    for (unsigned i = 0; i < w; ++i)
    {
        for (unsigned j = 0; j < h; ++j)
        {
            const Vector3d pixel_center = image_origin + (i + 0.5) * x_displacement + (j + 0.5) * y_displacement;

            // Prepare the ray
            Vector3d ray_origin;
            Vector3d ray_direction;

            if (is_perspective)
            {
                // Perspective camera
                ray_origin = camera_position;
                ray_direction = (pixel_center - camera_position).normalized();
            }
            else
            {
                // Orthographic camera
                ray_origin = pixel_center;
                ray_direction = Vector3d(0, 0, -1);
            }

            const Vector4d C = shoot_ray(ray_origin, ray_direction, max_bounce);
            R(i, j) = C(0);
            G(i, j) = C(1);
            B(i, j) = C(2);
            A(i, j) = C(3);
        }
    }

    // Save to png
    write_matrix_to_png(R, G, B, A, filename);
}

////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
    setup_scene();

    raytrace_scene();
    return 0;
}
